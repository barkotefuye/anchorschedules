    function init() {
      Tabletop.init( { key: 'https://docs.google.com/spreadsheets/d/1WA1WIo7ikwuO6VLVyQIzhngsI4RtKMBLo8gtbEispi0/pubhtml',
                     callback: getInfo,
                     simpleSheet: true } );
   }
      function getInfo(data, tabletop) {
      var ps= document.getElementById("password1").value;
      var un = document.getElementById("usernm").value;
      var btn = document.getElementById("btn");
      var err = document.getElementById("error");
      var li = document.getElementById("studentname");
      var i = 0;
      var j = true;

      for(i=0; i<data.length-1; i++){
        if(un == data[i].username && ps == data[i].password){
          console.log(un);
          window.location.assign("studentschedule2.html");
           if(window.location == "studentschedule2.html"){
              window.onload = function(){
                console.log(data[i].Name);
                sn.innerHTML = data[i].Name;
              }
            }
          return true;
        }
        else{
          var j = false;
        }
    }

    if (i + 1 == data.length && j == false){
      err.innerHTML = "incorrect username and password, please try again";
      err.style.fontSize = "50%";
      err.style.color="red";
      //ps.style.borderColor = "red";
      //un.style.borderColor = "red";
    }
  }  